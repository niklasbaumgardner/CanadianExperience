/**
 * \file TreePart.cpp
 *
 * \author Niklas Baumgardner
 */

#include "pch.h"
#include "TreePart.h"
#include "RealTree.h"

